﻿namespace StudentManagement.Models
{
    public enum Branch
    {
        IT,
        BE,
        CE,
        EE
    }
}
