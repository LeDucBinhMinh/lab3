﻿namespace StudentManagement.Models
{
    public enum Gender
    {
        Male, Female
    }
}
